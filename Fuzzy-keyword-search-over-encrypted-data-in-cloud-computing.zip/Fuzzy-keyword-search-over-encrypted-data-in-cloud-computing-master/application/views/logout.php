<!-- main_body  -->
<div class="main_body_wrapper">
	<div class="error">
	</div>
	
	<div class="reg_log">
			<h2>Logout Successful</h2>
	</div>
	
	<div id="admin_log">	
			<br>
			<br>
			<br>
			<center><h1> You have been sucessfully Logout..	</h1><br>
				<h1><a href="<?php echo base_url().'guest/index'; ?>">Click to login</a></h1>
			</center>
	</div>
	
	
</div>	
